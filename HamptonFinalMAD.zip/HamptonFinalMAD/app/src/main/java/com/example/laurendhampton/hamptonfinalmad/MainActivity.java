package com.example.laurendhampton.hamptonfinalmad;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.Toolbar;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    EditText name;
    ToggleButton sauce;
    RadioGroup crust;
    CheckBox pepperoni;
    CheckBox mushrooms;
    CheckBox onions;
    CheckBox sausage;
    Spinner pizzaSize;
    Switch glutenfree;
    Button pizza;
    TextView output;
    String saucetype;
    String crusttype;
    String sizetype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sauce = (ToggleButton) findViewById(R.id.toggleButton1);
        final Boolean red = sauce.isChecked();

        crust = (RadioGroup) findViewById(R.id.radioGroup);
        final int crust_id = crust.getCheckedRadioButtonId();

//        pepperoni = (CheckBox) findViewById(R.id.checkBox1);
//        Boolean pepperoniChecked = pepperoni.isChecked();
//
//        mushrooms = (CheckBox) findViewById(R.id.checkBox2);
//        boolean mushroomsChecked = mushrooms.isChecked();
//
//        onions = (CheckBox) findViewById(R.id.checkBox3);
//        boolean onionsChecked = onions.isChecked();
//
//        sausage = (CheckBox) findViewById(R.id.checkBox4);
//        boolean sausageChecked = sausage.isChecked();
//
//        pizzaSize = (Spinner) findViewById(R.id.spinner);
//        final String pizzaSizeType = String.valueOf(pizzaSize.getSelectedItem());

//        glutenfree = (Switch) findViewById(R.id.switch1);

        pizza = (Button) findViewById(R.id.button);

        output = (TextView) findViewById(R.id.output);

        pizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (crust_id == -1) {
                    //toast call
                    Context context = getApplicationContext();
                    Toast toast = Toast.makeText(context, "Please select one of the crusts", Toast.LENGTH_SHORT);
                    toast.show();
                    //I DONT KNOW WHY IT WONT LEAVE THIS OR GO INTO THE ELSE STATEMENT!!!!!
                } else {
                    if (red) { //sauce is red
//                        saucetype = "red";
                        if (crust_id == R.id.radioButton) { //thin crust
//                            crusttype = "Thin Crust";
                            switch (pizzaSize.getSelectedItem().toString()){
                                case "medium":
                                    sizetype = "medium";
                                    saucetype = "red";
                                    crusttype = "thin";
                                    break;
                                case "large":
                                    sizetype = "large";
                                    saucetype = "red";
                                    crusttype = "thin";
                                    break;
                                default:
                                    sizetype = "small";
                                    saucetype = "red";
                                    crusttype = "thin";
                            }
                        } else { //thick crust
//                            saucetype = "red";
//                            crusttype = "thick";
                            switch (pizzaSize.getSelectedItem().toString()){
                                case "medium":
                                    sizetype = "medium";
                                    saucetype = "red";
                                    crusttype = "thick";
                                    break;
                                case "large":
                                    sizetype = "large";
                                    saucetype = "red";
                                    crusttype = "thick";
                                    break;
                                default:
                                    sizetype = "small";
                                    saucetype = "red";
                                    crusttype = "thick";
                            }
                        }
                     }
                      else {
//                        saucetype = "white";
                        if (crust_id == R.id.radioButton) {
//                            crusttype = "Thin Crust";
                            switch (pizzaSize.getSelectedItem().toString()){
                                case "medium":
                                    sizetype = "medium";
                                    saucetype = "white";
                                    crusttype = "thin";
                                    break;
                                case "large":
                                    sizetype = "large";
                                    saucetype = "white";
                                    crusttype = "thin";
                                    break;
                                default:
                                    sizetype = "small";
                                    saucetype = "white";
                                    crusttype = "thin";
                            }
                        } else {
//                            crusttype = "Thick Crust";
                            switch (pizzaSize.getSelectedItem().toString()) {
                                case "medium":
                                    sizetype = "medium";
                                    saucetype = "white";
                                    crusttype = "thick";
                                    break;
                                case "large":
                                    sizetype = "large";
                                    saucetype = "white";
                                    crusttype = "thick";
                                    break;
                                default:
                                    sizetype = "small";
                                    saucetype = "white";
                                    crusttype = "thick";
                            }
                        }
                    }
                }

//=====================     ================== ================== ================== ================== ================== ==================

//TEXT OUTPUT STOPPED WORKING, SO MOSTLY DID THIS TO GIVE AN IDEA OF WHAT IT DID LOOK LIKE..................
                sizetype = "large";
                crusttype = "thin";
                saucetype = "red";
                output.setText("Your " + sizetype + " pizza has " + crusttype + " crust with " + saucetype + " sauce.");

            }
        });
    }
}