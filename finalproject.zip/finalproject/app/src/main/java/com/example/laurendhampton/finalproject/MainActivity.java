package com.example.laurendhampton.finalproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText numEditText;
    Button button1;
    TextView changingNumText;
    Spinner spinnerdist;
    Spinner spinnerfood;
    String theNum;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connections

        button1 = (Button) findViewById(R.id.button1);
        numEditText = (EditText) findViewById(R.id.numEditText);
        changingNumText = (TextView) findViewById(R.id.changingNumText);
        imageView = (ImageView) findViewById(R.id.imageView);

        //creating spinners

        spinnerdist = (Spinner) findViewById(R.id.spinnerDist);
        ArrayAdapter<CharSequence> adapterdist = ArrayAdapter.createFromResource(this, R.array.distanceunits, android.R.layout.simple_spinner_item);
        adapterdist.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); //specify the layout to use when the list of choices appears
        spinnerdist.setAdapter(adapterdist);

        spinnerfood = (Spinner) findViewById(R.id.spinnerFood);
        ArrayAdapter<CharSequence> adapterfood = ArrayAdapter.createFromResource(this, R.array.foodunits, android.R.layout.simple_spinner_item);
        adapterfood.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); //specify the layout to use when the list of choices appears
        spinnerfood.setAdapter(adapterfood);

        //implementing button and functions with it

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                theNum = numEditText.getText().toString();
                float num1 = Float.parseFloat(theNum);
                float finalNum;

                switch (spinnerdist.getSelectedItem().toString()) {
                    case "Miles":
                        switch (spinnerfood.getSelectedItem().toString()) {
                            case "Tacos":
                                imageView.setImageResource(R.drawable.taco);
                                finalNum = num1 * 11520;
                                break;
                            case "Ears of Corn":
                                imageView.setImageResource(R.drawable.corn);
                                finalNum = num1 * 9051;
                                break;
                            case "M&Ms":
                                imageView.setImageResource(R.drawable.mm);
                                finalNum = num1 * 158400;
                                break;
                            case "Watermelons":
                                imageView.setImageResource(R.drawable.watermelon);
                                finalNum = num1 * 2534;
                                break;
                            default:
                                imageView.setImageResource(R.drawable.pizza);
                                finalNum = num1 * 7040;
                                break;
                        }
                        break;
                    case "Feet":
                        switch (spinnerfood.getSelectedItem().toString()) {
                            case "Tacos":
                                imageView.setImageResource(R.drawable.taco);
                                finalNum = num1 * (Float.parseFloat("2.18"));
                                break;
                            case "Ears of Corn":
                                imageView.setImageResource(R.drawable.corn);
                                finalNum = num1 * (Float.parseFloat("1.71"));
                                break;
                            case "M&Ms":
                                imageView.setImageResource(R.drawable.mm);
                                finalNum = num1 * 30;
                                break;
                            case "Watermelons":
                                imageView.setImageResource(R.drawable.watermelon);
                                finalNum = num1 * (Float.parseFloat("0.48"));
                                break;
                            default:
                                imageView.setImageResource(R.drawable.pizza);
                                finalNum = num1 * (Float.parseFloat("1.33"));
                                break;
                        }
                        break;
                    default:
                        switch (spinnerfood.getSelectedItem().toString()) {
                            case "Tacos":
                                imageView.setImageResource(R.drawable.taco);
                                finalNum = num1 / (Float.parseFloat("5.5"));
                                break;
                            case "Ears of Corn":
                                imageView.setImageResource(R.drawable.corn);
                                finalNum = num1 / 7;
                                break;
                            case "M&Ms":
                                imageView.setImageResource(R.drawable.mm);
                                finalNum = num1 / (Float.parseFloat("0.4"));
                                break;
                            case "Watermelons":
                                imageView.setImageResource(R.drawable.watermelon);
                                finalNum = num1 / 25;
                                break;
                            default:
                                imageView.setImageResource(R.drawable.pizza);
                                finalNum = num1 / 9;
                                break;
                        }
                        break;
                }
                String display = String.valueOf(finalNum)+" "+(spinnerfood.getSelectedItem().toString());
                changingNumText.setText(display);
            }
        });
    }
}